import numpy as np
import warnings

from ..particle_sampling.sample_2d_slice import sample_2d_slice

def granular_temperature_3D(particle_data, container_data, point, vector_1, 
                            vector_2, plane_thickness, resolution,
                            bounds=None,
                            sample_column=None, 
                            velocity_column="v",
                            append_column="granuar_temperature",
                            particle_id_column="id"):
    """
    """
    if particle_data.n_points == 0:
        warnings.warn("Cannot sample empty particles file.", UserWarning)
        velocity_vectors = np.zeros((resolution[1], resolution[0], 2))
        velocity_vectors[:] = np.nan
        return particle_data, velocity_vectors, None
    
    if container_data.n_points == 0:
        warnings.warn("Cannot sample empty container file.", UserWarning)
        velocity_vectors = np.zeros((resolution[1], resolution[0], 2))
        velocity_vectors[:] = np.nan
        return particle_data, velocity_vectors, None
    
    vector_1 = vector_1 / np.linalg.norm(vector_1)
    vector_2 = vector_2 / np.linalg.norm(vector_2)

    particle_data, samples = sample_2d_slice(particle_data, 
                                        container_data, 
                                        point, 
                                        vector_1, 
                                        vector_2,
                                        plane_thickness, 
                                        resolution,
                                        bounds=bounds,
                                        append_column=sample_column,
                                        particle_id_column=particle_id_column
                                        )

    
    cell_ids = particle_data[samples.name].astype(int)
    velocities = particle_data.point_data[velocity_column]

    # Filter out -1 IDs (out of mesh elements)
    valid_mask = cell_ids != -1
    cell_ids_valid = cell_ids[valid_mask]
    velocities_valid = velocities[valid_mask]

    # Compute sum of velocities in each cell
    sum_vel = np.zeros((resolution[1] * resolution[0], 3))
    np.add.at(sum_vel, cell_ids_valid, velocities_valid)

    mean_vel = np.zeros_like(sum_vel)
    mean_vel[samples.occupied_cells] = ( 
                    sum_vel[samples.occupied_cells] 
                    / samples.particles[samples.occupied_cells, None]
                    )

    # Project onto vector_1 and vector_2
    mean_res_vec_1 = mean_vel @ vector_1
    mean_res_vec_2 = mean_vel @ vector_2

    resolved_velocity_vector = (
        mean_res_vec_1[:, None] * vector_1 +
        mean_res_vec_2[:, None] * vector_2
    )

    # Store results
    velocity_vectors = np.column_stack([mean_res_vec_1, mean_res_vec_2])
    cell_velocity = resolved_velocity_vector[cell_ids]

    # Set invalid cells to NaN
    cell_velocity[~valid_mask] = [np.nan, np.nan, np.nan]
    
    velocity_vectors_magnitude = np.linalg.norm(velocity_vectors, axis=2)

    velocity_deviation_vec_1 = np.zeros_like(velocities_valid)
    velocity_deviation_vec_2 = np.zeros_like(velocities_valid)
    for i, vel in enumerate(velocities_valid):
        resolved_velocity_vec_1 = vel @ vector_1
        mean_vec_1_vel = velocity_vectors[cell_ids_valid[i], 0]

        resolved_velocity_vec_2 = vel @ vector_2
        mean_vec_2_vel = velocity_vectors[cell_ids_valid[i], 1]

        velocity_deviation_vec_1[i] = (resolved_velocity_vec_1
                                        - mean_vec_1_vel) ** 2
        velocity_deviation_vec_2[i] = (resolved_velocity_vec_2 
                                       - mean_vec_2_vel) ** 2

    cell_deviation_vec_1 = np.zeros((resolution[1] * resolution[0]))
    cell_deviation_vec_2 = np.zeros((resolution[1] * resolution[0]))

    np.add.at(cell_deviation_vec_1, cell_ids_valid, velocity_deviation_vec_1)
    np.add.at(cell_deviation_vec_2, cell_ids_valid, velocity_deviation_vec_2)

    total_deviation = (
        2 * cell_deviation_vec_1 + cell_deviation_vec_2
    )

    mean_deviation = np.zeros_like(total_deviation)
    mean_deviation[samples.occupied_cells] = (
                    total_deviation[samples.occupied_cells]
                    / samples.particles[samples.occupied_cells, None]
                    )
    
    granular_temperature = 1/3 * mean_deviation
    granular_temperature = granular_temperature.reshape(resolution[1],
                                                       resolution[0])
    
    particle_granular_temperature = np.zeros_like(velocities)
    particle_granular_temperature[valid_mask] = granular_temperature[cell_ids_valid]

    particle_data[append_column] = particle_granular_temperature
    
    return particle_data, granular_temperature