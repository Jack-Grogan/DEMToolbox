import warnings

import numpy as np

from ..particle_sampling.sample_2d_slice import sample_2d_slice


def velocity_vector_field(particle_data, bounds, point, vector_1, 
                          vector_2, plane_thickness, resolution,
                          weighting_column=None,
                          sample_column=None, 
                          velocity_column="v",
                          append_column="mean_resolved_velocity",
                          particle_id_column="id"):
    """Calculate the velocity vector field of a 2D slice of particles.

    Parameters
    ----------
    particle_data : vtkPolyData
        The particle vtk.
    bounds : list, np.ndarray or vtkPolyData
        If a list or np.ndarray bounds of the sample space in the form 
        [x_min, x_max, y_min, y_max, z_min, z_max]. If a vtk, the bounds 
        will be determined from the vtk's bounds.
    point : list
        A point on the plane as [x, y, z].
    vector_1 : list
        The first sample vector to split the particles along.
    vector_2 : list
        The second sample vector to split the particles along.
    plane_thickness : int or float
        The thickness of the plane.
    resolution : list
        The resolution of the 2D sample space in the form [m, n].
    weighting_column: str, optional
        The column that defines the weighting contribution of each particle 
        to the mean velocity vector field. If None, the mean velocity vector 
        field will be calculated as the mean of the particle velocities in 
        each sample on a number basis and the resulting occupancy will be the 
        number of particles in each sample. Otherwise, the mean velocity vector 
        field will be calculated as the mean of the particle velocities in each 
        sample weighted by the values in the weighting column and the resulting 
        occupancy will be the sum of the values in the weighting column for 
        each sample. The weighting column must be a column in the particle data 
        point data. If the weighting column is not found in the particle data 
        point data, a ValueError will be raised.
    sample_column : str, optional
        The name of the samples column to append to the particle data,
        by default None. If None, the column name will be
        "particle_slice_p{point}_n{normal}".
    velocity_column : str, optional
        The name of the velocity column in the particle data, by default "v".
    append_column : str, optional
        The name of the column to append to the particle data, by default
        "mean_resolved_velocity".
    particle_id_column : str, optional
        The name of the particle id column in the particle data, by
        default "id".

    Returns
    -------
    particle_data : vtkPolyData
        The particle vtk with the mean resolved velocity column added.
    velocity_vectors : tuple
        An array of the mean resolved velocity vectors for particles in the
        sample space.
    occupancy : np.ndarray
        An array of the total occupancy values for each point in the sample 
        space. Shape will be (resolution[1], resolution[0]). Units will be 
        the same as the weighting column if provided, otherwise the units
        will be the number of particles in each sample.
    samples : ParticleSamples
        The samples object containing the sample information that was
        used to calculate the velocity vector field. if no particles
        are in the sample space, the samples object will be None.


    Raises
    ------
    ValueError
        If vectors are not 3 element lists.
    ValueError
        If point is not a 3 element list.
    ValueError
        If resolution is not a 2 element list of integers.
    ValueError
        If resolution is less than or equal to 0.
    ValueError
        If plane_thickness is not an integer or float.
    ValueError
        If plane_thickness is less than or equal to 0.
    VaueError
        If vectors are not orthogonal.
    UserWarning
        If the particle data has no points return unedited particle data
        and NaN array for the velocity vectors.
    UserWarning
        If the container data has no points return unedited particle data
        and NaN array for the velocity vectors.
    """

    
    if particle_data.n_points == 0:
        warnings.warn("Cannot sample empty container file."
                      "Returning unedited particle data.", UserWarning)
        velocity_vectors = np.zeros((resolution[1], resolution[0], 2))
        velocity_vectors[:] = np.nan
        occupancy = np.zeros((resolution[1], resolution[0]))
        return particle_data, velocity_vectors, occupancy, None
    
    
    vector_1 = vector_1 / np.linalg.norm(vector_1)
    vector_2 = vector_2 / np.linalg.norm(vector_2)

    particle_data, samples = sample_2d_slice(particle_data, 
                                        bounds, 
                                        point, 
                                        vector_1, 
                                        vector_2,
                                        plane_thickness, 
                                        resolution,
                                        append_column=sample_column,
                                        particle_id_column=particle_id_column
                                        )

    cell_ids = particle_data[samples.name].astype(int)
    velocities = particle_data.point_data[velocity_column]

    # Filter out -1 IDs (out of mesh elements)
    valid_mask = cell_ids != -1
    cell_ids_valid = cell_ids[valid_mask]
    velocities_valid = velocities[valid_mask]

    if weighting_column is None:
        sum_vel = np.zeros((resolution[1] * resolution[0], 3))
        np.add.at(sum_vel, cell_ids_valid, velocities_valid)

        weight_totals = samples.particles.astype(float)

        mean_vel = np.zeros_like(sum_vel)
        mean_vel[samples.occupied_cells] = (
            sum_vel[samples.occupied_cells]
            / weight_totals[samples.occupied_cells, None]
        )

        occupancy = samples.particles.reshape(resolution[1], resolution[0])
    else:

        if weighting_column not in particle_data.point_data:
            raise ValueError(f"Weighting column '{weighting_column}' not found "
                             "in particle data point data.")

        weighting = particle_data.point_data[weighting_column]
        weighting_valid = weighting[valid_mask]

        sum_vel = np.zeros((resolution[1] * resolution[0], 3))
        np.add.at(sum_vel, cell_ids_valid,
                velocities_valid * weighting_valid[:, None])

        weight_totals = np.zeros(resolution[1] * resolution[0])
        np.add.at(weight_totals, cell_ids_valid, weighting_valid)

        occupancy = weight_totals.reshape(resolution[1], resolution[0])

        mean_vel = np.zeros_like(sum_vel)
        mean_vel[samples.occupied_cells] = (
            sum_vel[samples.occupied_cells]
            / weight_totals[samples.occupied_cells, None]
        )

    # Project onto vector_1 and vector_2
    mean_res_vec_1 = mean_vel @ vector_1
    mean_res_vec_2 = mean_vel @ vector_2

    resolved_velocity_vector = (
        mean_res_vec_1[:, None] * vector_1 +
        mean_res_vec_2[:, None] * vector_2
    )

    # Store results
    velocity_vectors = np.column_stack([mean_res_vec_1, mean_res_vec_2])
    cell_velocity = resolved_velocity_vector[cell_ids]

    # Set invalid cells to NaN
    cell_velocity[~valid_mask] = [np.nan, np.nan, np.nan]

    velocity_vectors = velocity_vectors.reshape(resolution[1],
                                                resolution[0], 2)

    particle_data[append_column] = cell_velocity

    return particle_data, velocity_vectors, occupancy, samples